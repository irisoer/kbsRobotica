create definer = root@localhost trigger `email-orderCustomer`
    before insert
    on orderCustomer
    for each row
BEGIN
    IF NEW.emailadres NOT LIKE '_%@_%.__%' THEN
          SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Email niet juist';
END IF;
END;

