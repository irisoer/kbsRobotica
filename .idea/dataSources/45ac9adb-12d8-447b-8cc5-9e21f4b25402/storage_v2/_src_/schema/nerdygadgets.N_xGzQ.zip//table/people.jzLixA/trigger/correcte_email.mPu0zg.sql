create definer = root@localhost trigger correcte_email
    before insert
    on people
    for each row
BEGIN
IF NEW.EmailAddress NOT LIKE '_%@_%.__%' THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Email field is not valid';
END IF;
END;

