create definer = root@localhost trigger `postcode-orderCustomer`
    before insert
    on orderCustomer
    for each row
BEGIN
    IF NEW.postcode NOT LIKE '[1-9][0-9][0-9][0-9][A-Z][A-Z]'
  AND NEW.postcode NOT LIKE'[1-9][0-9][0-9][0-9] [A-Z][A-Z]' THEN
       SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Postcode niet juist';
END IF;
END;

